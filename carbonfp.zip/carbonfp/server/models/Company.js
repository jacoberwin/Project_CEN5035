import mongoose from "mongoose";

const companySchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  approved: { type: Boolean, default: false },
  credits: { type: Number, default: 0 }
});

export default mongoose.model("Company", companySchema);
