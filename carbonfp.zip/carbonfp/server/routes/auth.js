import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

import User from '../models/User.js';
import Company from '../models/Company.js';

dotenv.config();

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret';

// ─────────────────────────────────────────────────────────────
// REGISTER: Only for employee & employer (not admin)
// ─────────────────────────────────────────────────────────────
router.post('/register', async (req, res) => {
  const { company, username, password, role } = req.body;

  if (role === 'admin') {
    return res.status(403).json({ error: 'Registration as admin is not allowed' });
  }

  try {
    // Check if company exists and is approved
    const companyRecord = await Company.findOne({ name: company });
    if (!companyRecord || !companyRecord.approved) {
      return res.status(400).json({ error: 'Company not found or not approved yet' });
    }

    // Check for duplicate username
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ error: 'Username already exists' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user with status pending
    await User.create({
      username,
      password: hashedPassword,
      role,
      companyId: companyRecord._id,
      status: 'pending',
    });

    res.status(201).json({ message: `${role} registered successfully. Awaiting approval.` });
  } catch (err) {
    res.status(500).json({ error: 'Registration failed. Try again later.' });
  }
});

// ─────────────────────────────────────────────────────────────
// LOGIN
// ─────────────────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  const { company, username, password, role } = req.body;

  try {
    // Match user with company and role
    const user = await User.findOne({ username, role }).populate('companyId');

    if (!user || (user.role !== 'admin' && user.companyId?.name !== company)) {
      return res.status(404).json({ error: 'User not found with provided credentials' });
    }

    if (user.status !== 'approved') {
      return res.status(403).json({ error: 'Your account has not been approved yet' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ error: 'Invalid password' });

    const token = jwt.sign(
      {
        id: user._id,
        role: user.role,
        companyId: user.companyId?._id,
      },
      JWT_SECRET,
      { expiresIn: '1d' }
    );

    res.json({
      token,
      user: {
        id: user._id,
        username: user.username,
        role: user.role,
        companyId: user.companyId?._id,
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Login failed. Try again later.' });
  }
});

// ─────────────────────────────────────────────────────────────
// GET All Users (optional for admin panel or debugging)
// ─────────────────────────────────────────────────────────────
router.get('/users', async (req, res) => {
  const users = await User.find().populate('companyId');
  res.json(users);
});

export default router;
