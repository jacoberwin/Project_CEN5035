import express from 'express';
import { verifyToken, checkRole } from '../middleware/auth.js';
import User from '../models/User.js';

const router = express.Router();

// ✅ GET all employers (pending/approved)
router.get('/', verifyToken, checkRole(['admin']), async (req, res) => {
  const isApproved = req.query.approved === 'true';
  try {
    const employers = await User.find({
      role: 'employer',
      status: isApproved ? 'approved' : 'pending',
    });
    res.json(employers);
  } catch (err) {
    res.status(500).json({ error: 'Server error fetching companies' });
  }
});

// ✅ Admin approves employers
router.patch('/company/:id/approve', verifyToken, checkRole(['admin']), async (req, res) => {
  const user = await User.findByIdAndUpdate(req.params.id, { status: 'approved' }, { new: true });
  if (!user || user.role !== 'employer') return res.status(400).json({ error: 'Invalid company' });
  res.json({ message: 'Company approved', user });
});

// ✅ Employer approves employees
router.patch('/employee/:id/approve', verifyToken, checkRole(['employer']), async (req, res) => {
  const user = await User.findByIdAndUpdate(req.params.id, { status: 'approved' }, { new: true });
  if (!user || user.role !== 'employee') return res.status(400).json({ error: 'Invalid employee' });
  res.json({ message: 'Employee approved', user });
});

export default router;
