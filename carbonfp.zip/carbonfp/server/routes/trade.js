import express from "express";
import Trade from "../models/Trade.js";
import Company from "../models/Company.js";
import { verifyToken } from "../middleware/auth.js";

const router = express.Router();

// Employer creates trade request
router.post("/", verifyToken, async (req, res) => {
  try {
    const { companyId, type, amount } = req.body;
    if (req.user.role !== "employer") return res.status(403).json({ message: "Unauthorized" });

    const company = await Company.findById(companyId);
    if (!company || (type === "sell" && company.credits < amount)) {
      return res.status(400).json({ message: "Invalid request or insufficient credits" });
    }

    const trade = await Trade.create({ companyId, type, amount });
    res.status(201).json(trade);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get trades for a company
router.get("/company/:companyId", verifyToken, async (req, res) => {
  try {
    const trades = await Trade.find({ companyId: req.params.companyId });
    res.json(trades);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin approves/rejects trade
router.patch("/:id", verifyToken, async (req, res) => {
  try {
    if (req.user.role !== "admin") return res.status(403).json({ message: "Forbidden" });

    const trade = await Trade.findById(req.params.id);
    const company = await Company.findById(trade.companyId);
    const status = req.body.status;

    if (status === "approved") {
      trade.type === "buy"
        ? company.credits += trade.amount
        : company.credits -= trade.amount;
      await company.save();
    }

    trade.status = status;
    await trade.save();
    res.json(trade);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin fetches all trades
router.get("/", verifyToken, async (req, res) => {
  if (req.user.role !== "admin") return res.status(403).json({ message: "Unauthorized" });
  const trades = await Trade.find({});
  res.json(trades);
});

export default router;
