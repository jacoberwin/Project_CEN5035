import { Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import EmployeeDashboard from "./pages/EmployeeDashboard";
import EmployerDashboard from "./pages/EmployerDashboard";
import AdminDashboard from "./pages/AdminDashboard";

function App() {
  return (
    <div className="font-poppins">
      <Routes>
        {/* Public Route */}
        <Route path="/" element={<Login />} />

        {/* Role-based Dashboards */}
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/employer" element={<EmployerDashboard />} />
        <Route path="/employee" element={<EmployeeDashboard />} />
      </Routes>
    </div>
  );
}

export default App;
