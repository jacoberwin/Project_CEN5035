import { useNavigate } from "react-router-dom";

const Navbar = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const handleLogout = () => {
    localStorage.clear();
    navigate("/");
  };

  return (
    <header className="bg-green-700 text-white px-6 py-4 shadow-md fixed top-0 w-full z-50">
      <h1 className="text-3xl font-extrabold tracking-wide text-white">
        CarbonFP
      </h1>

      <div className="flex flex-col md:flex-row items-start md:items-center gap-2 md:gap-4">
        {user && (
          <span className="text-sm md:text-base font-medium">
            Logged in as:{" "}
            <span className="font-semibold capitalize">{user.role}</span>
          </span>
        )}
        <button
          className="bg-white text-green-700 hover:bg-gray-100 font-semibold px-4 py-1.5 rounded transition duration-200"
          onClick={handleLogout}
        >
          Logout
        </button>
      </div>
    </header>
  );
};

export default Navbar;
