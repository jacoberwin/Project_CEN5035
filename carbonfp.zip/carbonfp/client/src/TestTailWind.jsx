export default function TestTailwind() {
    return (
      <div className="min-h-screen flex justify-center items-center bg-gradient-to-br from-blue-100 to-green-100">
        <h1 className="text-4xl font-bold text-blue-800">
          ✅ Tailwind is working!
        </h1>
      </div>
    );
  }
  