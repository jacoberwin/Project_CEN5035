// client/src/pages/EmployerDashboard.jsx
import { useEffect, useState } from "react";
import axios from "axios";

const EmployerDashboard = () => {
  const [trades, setTrades] = useState([]);
  const [amount, setAmount] = useState("");
  const [type, setType] = useState("buy");

  const companyId = localStorage.getItem("companyId");
  const token = localStorage.getItem("token");

  const fetchTrades = async () => {
    try {
      const res = await axios.get(`/api/trades/company/${companyId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setTrades(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const requestTrade = async () => {
    try {
      await axios.post(
        "/api/trades",
        { companyId, type, amount: Number(amount) },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setAmount("");
      fetchTrades();
    } catch (err) {
      alert(err.response?.data?.message || "Trade request failed");
    }
  };

  useEffect(() => {
    fetchTrades();
  }, []);

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-bold text-green-700">Employer Dashboard</h1>

      <div className="space-x-4">
        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="border rounded px-2 py-1"
        >
          <option value="buy">Buy</option>
          <option value="sell">Sell</option>
        </select>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Amount"
          className="border px-2 py-1 rounded"
        />
        <button
          onClick={requestTrade}
          className="bg-blue-600 text-white px-4 py-1 rounded"
        >
          Request Trade
        </button>
      </div>

      <div>
        <h2 className="font-semibold text-lg">Trade History</h2>
        <ul className="space-y-2 mt-2">
          {trades.map((t) => (
            <li
              key={t._id}
              className="border p-2 rounded shadow-sm flex justify-between items-center"
            >
              {t.type.toUpperCase()} — {t.amount} credits
              <span
                className={`text-sm font-semibold ${
                  t.status === "approved"
                    ? "text-green-600"
                    : t.status === "rejected"
                    ? "text-red-600"
                    : "text-yellow-600"
                }`}
              >
                {t.status}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default EmployerDashboard;
