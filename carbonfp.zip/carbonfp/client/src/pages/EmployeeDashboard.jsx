import { useState } from "react";
import axios from "axios";

const EmployeeDashboard = () => {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [distance, setDistance] = useState(null);
  const [credits, setCredits] = useState(null);
  const [logs, setLogs] = useState([]);

  const calculateDistance = async () => {
    try {
      const res = await axios.post("http://localhost:5000/api/travel/calculate", { from, to });
      setDistance(res.data.distance);
      setCredits(res.data.credits);
    } catch (err) {
      alert("Error calculating distance");
    }
  };

  const logTravel = async () => {
    try {
      const token = localStorage.getItem("token");
      await axios.post("http://localhost:5000/api/travel/log", {
        from,
        to,
        distance,
        credits,
      }, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchLogs();
    } catch (err) {
      alert("Error logging travel");
    }
  };

  const fetchLogs = async () => {
    const token = localStorage.getItem("token");
    const user = JSON.parse(localStorage.getItem("user"));
    const res = await axios.get(`http://localhost:5000/api/travel/user/${user.id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    setLogs(res.data);
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Employee Dashboard</h1>

      <div className="grid gap-4 max-w-xl">
        {/* 👤 Role Display First */}
        <select
          disabled
          value="employee"
          className="p-2 border rounded bg-gray-100 text-gray-600 cursor-not-allowed"
        >
          <option value="employee">👤 Role: Employee</option>
        </select>

        <input
          type="text"
          value={from}
          onChange={(e) => setFrom(e.target.value)}
          placeholder="Home Address"
          className="p-2 border rounded"
        />
        <input
          type="text"
          value={to}
          onChange={(e) => setTo(e.target.value)}
          placeholder="College Address"
          className="p-2 border rounded"
        />
        
        <button
          onClick={calculateDistance}
          className="bg-blue-600 text-white py-2 px-4 rounded"
        >
          Calculate Distance
        </button>

        {distance && (
          <p className="mt-2">📍 Distance: {distance} km | 🎁 Credits: {credits}</p>
        )}

        {distance && (
          <button
            onClick={logTravel}
            className="bg-green-600 text-white py-2 px-4 rounded"
          >
            Log Travel
          </button>
        )}
      </div>

      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-2">Travel Logs</h2>
        <table className="w-full border">
          <thead className="bg-gray-200">
            <tr>
              <th className="p-2 border">From</th>
              <th className="p-2 border">To</th>
              <th className="p-2 border">Distance</th>
              <th className="p-2 border">Credits</th>
              <th className="p-2 border">Date</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((log) => (
              <tr key={log._id}>
                <td className="p-2 border">{log.from}</td>
                <td className="p-2 border">{log.to}</td>
                <td className="p-2 border">{log.distance}</td>
                <td className="p-2 border">{log.credits}</td>
                <td className="p-2 border">{new Date(log.date).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default EmployeeDashboard;
