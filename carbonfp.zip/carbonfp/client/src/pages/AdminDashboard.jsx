import { useNavigate } from "react-router-dom";

const Navbar = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const handleLogout = () => {
    localStorage.clear();
    navigate("/");
  };

  return (
    <div className="bg-green-700 text-white px-6 py-4 flex justify-between items-center shadow-md">
      <h1 className="text-2xl md:text-3xl font-extrabold tracking-wide">CarbonFP</h1>
      <div className="flex items-center gap-4">
        {user && (
          <span className="text-sm md:text-base font-medium">
            Logged in as: <span className="font-semibold">{user.role}</span>
          </span>
        )}
        <button
          className="bg-white text-green-700 hover:bg-gray-100 font-semibold px-3 py-1 rounded"
          onClick={handleLogout}
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default Navbar;
