import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import logo from "../assets/carbonfp-logo.jpg";

export default function Login() {
  const [form, setForm] = useState({
    company: "",
    username: "",
    password: "",
    role: "employee",
  });

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await axios.post("http://localhost:5050/api/auth/login", form);

      const { token, user } = res.data;

      // ✅ Store login data
      localStorage.setItem("token", token);
      localStorage.setItem("user", JSON.stringify(user));
      localStorage.setItem("role", user.role);

      if (user.companyId) {
        localStorage.setItem("companyId", user.companyId);
      }

      // ✅ Debug logs
      console.log("Login success:", user);
      console.log("Navigating to:", `/${user.role}`);

      // ✅ Redirect to role-based dashboard
      navigate(`/${user.role}`);
    } catch (err) {
      setError(err.response?.data?.error || "Login failed");
      console.error("Login error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-blue-200 flex items-center justify-center px-4 font-sans">
      <div className="p-2 bg-green-600 rounded-xl">
        <div className="p-2 bg-black rounded-xl">
          <form
            onSubmit={handleLogin}
            className="w-[480px] bg-white p-8 rounded-xl shadow-lg text-center"
          >
            {/* Logo */}
            <div className="flex justify-center mb-6">
              <img
                src={logo}
                alt="Carbonfp Logo"
                className="w-64 h-28 object-contain rounded"
              />
            </div>

            {/* Heading */}
            <h2 className="text-3xl font-extrabold text-blue-700 mb-8 font-poppins">
              Login to CarbonFP
            </h2>

            {/* Error Message */}
            {error && <p className="text-red-500 text-sm mb-4">{error}</p>}

            {/* Role */}
            <div className="mb-4">
              <label className="block text-sm font-semibold mb-1 text-center">Role</label>
              <select
                name="role"
                value={form.role}
                onChange={handleChange}
                className="w-full p-2 rounded border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-300"
              >
                <option value="employee">Employee</option>
                <option value="employer">Employer</option>
                <option value="admin">Admin</option>
              </select>
            </div>

            {/* Company */}
            {form.role !== "admin" && (
              <div className="mb-4">
                <label className="block text-sm font-semibold mb-1 text-center">Company</label>
                <input
                  type="text"
                  name="company"
                  value={form.company}
                  onChange={handleChange}
                  className="w-full p-2 rounded border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-300"
                  required
                />
              </div>
            )}

            {/* Username */}
            <div className="mb-4">
              <label className="block text-sm font-semibold mb-1 text-center">Username</label>
              <input
                type="text"
                name="username"
                value={form.username}
                onChange={handleChange}
                className="w-full p-2 rounded border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-300"
                required
              />
            </div>

            {/* Password */}
            <div className="mb-6">
              <label className="block text-sm font-semibold mb-1 text-center">Password</label>
              <input
                type="password"
                name="password"
                value={form.password}
                onChange={handleChange}
                className="w-full p-2 rounded border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-300"
                required
              />
            </div>

            {/* Login Button */}
            <button
              type="submit"
              className={`w-full py-2 text-white text-sm font-semibold rounded-md transition ${
                loading ? "bg-gray-400 cursor-not-allowed" : "bg-blue-600 hover:bg-blue-700"
              }`}
              disabled={loading}
            >
              {loading ? "Logging in..." : "Login"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
